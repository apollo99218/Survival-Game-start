using System.Collections.Generic;
using UnityEngine;

namespace SurvivalTemplatePro
{
    public interface ISTPEventReferenceHandler
    {
        Component GetEventReferencesSource();
    }
}