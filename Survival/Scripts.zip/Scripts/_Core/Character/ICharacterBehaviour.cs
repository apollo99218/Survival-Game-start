﻿namespace SurvivalTemplatePro
{
    public interface ICharacterBehaviour
    {
        /// <summary>
        /// Initialize this behaviour.
        /// </summary>
        void InititalizeBehaviour(ICharacter character);
    }
}