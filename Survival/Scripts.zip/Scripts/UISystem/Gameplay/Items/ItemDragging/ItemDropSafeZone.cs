using UnityEngine;

namespace SurvivalTemplatePro.UISystem
{
    public class ItemDropSafeZone : MonoBehaviour 
    {

    }
}