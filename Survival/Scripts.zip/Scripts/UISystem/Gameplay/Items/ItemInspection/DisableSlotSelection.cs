using UnityEngine;

namespace SurvivalTemplatePro.UISystem
{
    public class DisableSlotSelection : MonoBehaviour
    {

    }
}