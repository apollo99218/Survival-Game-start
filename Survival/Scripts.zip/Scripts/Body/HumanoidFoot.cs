namespace SurvivalTemplatePro.BodySystem
{
    public enum HumanoidFoot
    {
        Left, Right
    }
}