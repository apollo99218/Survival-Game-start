﻿namespace SurvivalTemplatePro.BodySystem
{
    public enum ItemAttachPoint 
    {
        Hips,
        LeftHand,
        RightHand,
        LeftShoulder,
        RightShoulder
    }

    public enum ClothingType
    {
        Torso,
        Head,
        Legs,
        Feet,
        Hands
    }
}