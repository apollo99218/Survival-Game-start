﻿namespace SurvivalTemplatePro.WieldableSystem
{
    public interface IFirearmAttachment
    {
        void Attach();
        void Detach();
    }
}