using SurvivalTemplatePro.InventorySystem;

namespace SurvivalTemplatePro.WieldableSystem
{
    public static class AttachmentsSystemHelper
    {

    }
}