﻿namespace SurvivalTemplatePro
{
    public interface IProjectile
	{
		void Launch(ICharacter launcher);
	}
}