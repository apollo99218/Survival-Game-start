namespace SurvivalTemplatePro.WieldableSystem
{
    public interface IChargeHandler
    {
        float GetNormalizedCharge();
    }
}