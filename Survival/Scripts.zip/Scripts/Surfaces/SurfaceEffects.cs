﻿namespace SurvivalTemplatePro.Surfaces
{
	public enum SurfaceEffects
	{
		SoftFootstep,
		HardFootstep,
		FallImpact,
		BulletHit,
		Slash,
		Stab,
		Hit
	}
}