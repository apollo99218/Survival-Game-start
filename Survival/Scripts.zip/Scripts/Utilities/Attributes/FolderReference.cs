using UnityEngine;

namespace SurvivalTemplatePro
{
    [System.Serializable]
    public class FolderReference : PropertyAttribute
    {
        public string guid;
    }
}