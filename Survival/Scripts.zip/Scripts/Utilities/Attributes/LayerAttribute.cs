﻿using UnityEngine;

namespace SurvivalTemplatePro
{
    public class LayerAttribute : PropertyAttribute
    {
        
    }
}