﻿using UnityEngine;

namespace SurvivalTemplatePro
{
    public class TagAttribute : PropertyAttribute
    {

    }
}