﻿using UnityEngine;

namespace SurvivalTemplatePro
{
	public class ReadOnlyAttribute : PropertyAttribute 
	{

	}
}