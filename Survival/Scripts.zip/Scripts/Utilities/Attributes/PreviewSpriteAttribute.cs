﻿using UnityEngine;

namespace SurvivalTemplatePro
{
    public class PreviewSpriteAttribute : PropertyAttribute
    {


    }
}