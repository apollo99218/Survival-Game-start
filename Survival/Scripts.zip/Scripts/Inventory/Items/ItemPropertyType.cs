namespace SurvivalTemplatePro.InventorySystem
{
    public enum ItemPropertyType
    {
        Boolean,
        Integer,
        Float,
        Item,
        Attachment
    }
}