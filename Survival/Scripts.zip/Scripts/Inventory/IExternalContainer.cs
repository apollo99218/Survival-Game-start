using SurvivalTemplatePro.InventorySystem;

namespace SurvivalTemplatePro
{
    public interface IExternalContainer
    {
        ItemContainer ItemContainer { get; }
    }
}